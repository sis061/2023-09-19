//섹션02 어제 베스트셀러 배너 슬라이드 autoslide & 버튼 click -> 슬라이드 & 페이지네이션 변경
$(function () {
    var i = 0;
    $(".section02_ebook_banner_wrap .swiper_wrapper").slick({
        slidesToShow: 1,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 2000,
        pauseOnHover: true,
        arrows: false
    });

    $(".section02_ebook_banner_wrap .swiper_wrapper").on('afterChange', function (event, slick, currentSlide) {
        var i = currentSlide + 1;
        $(".section02_ebook_banner_wrap .swiper-pagination-current").text(i);
    })

    $(".section02_ebook_banner_wrap .swiper_btn_prev").click(function (e) {
        $(".section02_ebook_banner_wrap .swiper_wrapper").slick("slickPrev");
    });

    $(".section02_ebook_banner_wrap .swiper_btn_next").click(function (e) {
        $(".section02_ebook_banner_wrap .swiper_wrapper").slick("slickNext");

    });
});