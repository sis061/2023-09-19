//메인 슬라이드 배너 슬라이드 func
$(function () {
    $(".banner_slide_list .swiper_wrapper").slick({
        slidesToScroll: 3,
        slidesToShow: 3,
        arrows: false,
        speed: 500,
        autoplay: true,
        autoplaySpeed: 2000,
        pauseOnHover: true
    });

    $(".banner_slide .circle_default_prev").click(function (e) {
        $(".banner_slide .swiper_wrapper").slick("slickPrev");
    });

    $(".banner_slide .circle_default_next").click(function (e) {
        $(".banner_slide .swiper_wrapper").slick("slickNext");
    });
});