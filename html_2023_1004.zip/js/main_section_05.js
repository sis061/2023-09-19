//섹션 05 슬라이더 func
$(function () {
    $(".section05_list .swiper_wrapper").slick({
        slidesToScroll: 3,
        slidesToShow: 3,
        arrows: false,
        speed: 300,
        variableWidth: true
    });

    $(".section05 .circle_default_prev").click(function (e) {
        $(".section05 .swiper_wrapper").slick("slickPrev");
    });

    $(".section05 .circle_default_next").click(function (e) {
        $(".section05 .swiper_wrapper").slick("slickNext");
    });
});