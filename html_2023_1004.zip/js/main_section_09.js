//섹션 09 슬라이더 func
$(function () {
    $(".section09_list .swiper_wrapper").slick({
        slidesToScroll: 5,
        slidesToShow: 5,
        arrows: false,
        speed: 300,
        variableWidth: true
    });

    $(".section09 .circle_default_prev").click(function (e) {
        $(".section09 .swiper_wrapper").slick("slickPrev");
    });

    $(".section09 .circle_default_next").click(function (e) {
        $(".section09 .swiper_wrapper").slick("slickNext");
    });
});