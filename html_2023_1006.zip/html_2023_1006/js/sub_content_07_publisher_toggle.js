/*--------------- content 08 출판사 내용 더보기, 접기 func -------------------*/
            function publisherTextShow() {
                $('#publisher_content_text_short').hide();
                $('#publisher_content_text_full').show();
            }

            function publisherTextHide() {
                $('#publisher_content_text_short').show();
                $('#publisher_content_text_full').hide();
            }

