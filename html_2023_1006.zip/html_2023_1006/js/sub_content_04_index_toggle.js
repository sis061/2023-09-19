
/*--------------- content 04 목차 더보기, 접기 func -------------------*/
function pageShow() {
    $('#index_content_short').hide();
    $('#index_content_full').show();
}

function pageHide() {
    $('#index_content_short').show();
    $('#index_content_full').hide();
}
